<?php $__env->startSection('content'); ?>

    <div class="banner product-banner">
        <h1><?php echo e($title); ?></h1>
        <p>Spark Inc / <?php echo e($title); ?></p>
    </div>

    <article>Ensure you're always prepared for emergencies with our comprehensive medical kits, designed to provide essential first aid supplies for home, work, or travel.</article>

    <div class="products-container">

        <?php if(isset($searchtitle)): ?>
            <h4 class="mt-2"><?php echo e($searchtitle); ?></h4>
        <?php endif; ?>

        <?php if($products->isEmpty()): ?>
            <h4 style="margin-top:4%">No products available</h4>
    
        <?php else: ?>
            <div class="main-prod-container">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="prod-cards" data-aos="fade-up" data-aos-duration="800">
                    <div class="prod-image">
                        <img src="<?php echo e(asset('storage/images/' . $product->image)); ?>" alt="product-image">
                    </div>

                    <div class="prod-details">
                        <h1><?php echo e($product->name); ?></h1>
                        <span>Brand: <?php echo e($product->brand); ?></span>
                        <p>Rs.<?php echo e($product->unit_price); ?></p>
                        <p>
                            <!-- <button class="btn btn-primary cart-btn">Add to Cart</button> -->
                        </p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/PHP/sparkinc/sparkinc/resources/views/frontend/product.blade.php ENDPATH**/ ?>