<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Spark Inc</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <header class="admin-header">
        <div class="admin-logo">
            <h1>SPARK INC</h1>
        </div>
        <div class="admin-nav-header">
            <ul style="list-style:none";>
                <li>
                    <div class="dropdown-icon">
                        <img src="<?php echo e(asset('/images/logo.png')); ?>" alt="">
                    </div>
                </li>
            </ul>
        </div>
    </header>

    <section class="admin-section">
        <aside>
            <nav class="admin-nav">
                <ul>
                    <li class="<?php echo e($slug === 'dashboard' ? 'activeadminnav' : ''); ?>">
                        <a href="/admin"><i class="fa fa-tachometer-alt"></i> &nbsp;Dashboard</a>
                    </li>

                    <li class="<?php echo e($slug === 'dashboardproducts' ? 'activeadminnav' : ''); ?>">
                        <a href="/admin/products"><i class="fa fa-boxes"></i> &nbsp;Products</a>
                    </li>

                    <li class="<?php echo e($slug === 'dashboardblogs' ? 'activeadminnav' : ''); ?>">
                        <a href="/admin/blogs"><i class="fa fa-blog"></i> &nbsp;Blogs</a>
                    </li>

                    <li class="<?php echo e($slug === 'dashboardmessage' ? 'activeadminnav' : ''); ?>">                       
                        <a href="/admin/messages"><i class="fa fa-envelope" style="padding-left:0"></i> &nbsp;Messages</a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();"><i class="fa fa-sign-out-alt"></i> &nbsp;
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    
                    </li>
                </ul>
            </nav>
        </aside>

        <?php echo $__env->yieldContent('content'); ?>

        </section>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                document.querySelectorAll('#blogdescription, #editblogdescription, #productdescription, #editproductdescription').forEach(editorElement => {
                    ClassicEditor
                        .create(editorElement)
                        .catch(error => {
                            console.error(error);
                        });
                });
            });
        </script>
        
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/PHP/sparkinc/sparkinc/resources/views/admin/layouts/admin.blade.php ENDPATH**/ ?>