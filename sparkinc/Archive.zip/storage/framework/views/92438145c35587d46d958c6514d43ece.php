<?php $__env->startSection('content'); ?>

    <div class="admin-content">
        <div class="cards-container">
            <div class="admin-card" >
                <div class="admin-card-body">
                    <h5 class="card-title">Messages</h5>
                    <p class="card-text" style="font-size:2rem"><?php echo e($totalMessages); ?></p>
                </div>
            </div>

            <div class="admin-card" >
                <div class="admin-card-body">
                    <h5 class="card-title">Products</h5>
                    <p class="card-text" style="font-size:2rem"><?php echo e($totalProducts); ?></p>
                </div>
            </div>

            <div class="admin-card" >
                <div class="admin-card-body">
                    <h5 class="card-title">Blogs</h5>
                    <p class="card-text" style="font-size:2rem"><?php echo e($totalBlogs); ?></p>
                </div>
            </div>
            
        </div>

        <div class="admin-highlights">
            <h1>Recent Interactions</h1>
            <table class="table table-striped msg-table-admin">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Firstname</th>
                        <th scope="col">Lastname</th>
                        <th scope="col">Email</th>
                        <th scope="col">Message</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($message->id); ?></th>
                        <td><?php echo e($message->firstname); ?></td>
                        <td><?php echo e($message->lastname); ?></td>
                        <td><?php echo e($message->email); ?></td>
                        <td><?php echo e($message->message); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/PHP/sparkinc/sparkinc/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>