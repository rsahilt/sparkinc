<?php $__env->startSection('content'); ?>

    <div class="single-blog">
        <div class="singleblog-description">
            <p style="margin-bottom:0" class="text-secondary">Blog, <?php echo e($information->category); ?></p>
            <em><p style="margin-bottom:0" class="text-secondary">Posted By: <?php echo e($information->author); ?> on <?php echo e($information->created_at->format('d F, Y')); ?></p></em>
            <h3 style="margin-top:0"><?php echo e($information->title); ?></h3>
            <img src="/storage/images/<?php echo e($information->image); ?>" alt="<?php echo e($information->name); ?>">
            <p>
                <?php echo $information->description; ?>

            </p>
        </div>
    </div>
        
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/PHP/sparkinc/sparkinc/resources/views/frontend/blogsingle.blade.php ENDPATH**/ ?>