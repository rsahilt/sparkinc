<?php $__env->startSection('content'); ?>
    <div class="admin-content">
    <?php if(session('success')): ?>
            <div id="successMessage" class="alert alert-success mt-7 rounded-lg bg-green-200">
                <?php echo e(session('success')); ?>

            </div>
            <script>
                setTimeout(function() {
                    document.getElementById('successMessage').style.display = 'none';
                }, 3000);
            </script>
        <?php endif; ?>

        <?php if(session('danger')): ?>
            <div id="dangerMessage" class="alert alert-danger mt-7 rounded-lg bg-red-200">
                <?php echo e(session('danger')); ?>

            </div>
            <script>
                setTimeout(function() {
                    document.getElementById('dangerMessage').style.display = 'none';
                }, 3000);
            </script>
        <?php endif; ?>
        
        <div class="admin-prod-container">
            <h1><?php echo e($title); ?></h1>

            <div class="add-new">
                <a href="/admin/products/create">Add Product</a>
            </div>

        
            <div class="admin-prod-table">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Image</th>
                            <th scope="col">Product</th>
                            <th scope="col">Brand</th>
                            <th scope="col">Unit Price</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($product->id); ?></th>
                            <td><img src="<?php echo e(asset('storage/images/' . $product->image)); ?>" class="admin-prod-thumbnail" alt="<?php echo e($product->name); ?>"></td>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->brand); ?></td>
                            <td><?php echo e($product->unit_price); ?></td>
                            <td class="px-6 py-4 text-left">
                                <div class="inline-block" style="display:flex;">
                                    <a href="<?php echo e(route('editproduct', ['id' => $product->id])); ?>" class="admin-edit-btn font-medium text-blue-600 dark:text-blue-500 hover:underline">Edit</a>
                                    <!-- asking the user if they really want to delete, in the form of an alert -->
                                    <form action="<?php echo e(route('deleteproducts', $product->id)); ?>" method="POST" novalidate class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="admin-delete-btn font-medium text-blue-600 dark:text-blue-500 hover:underline" onclick="return confirm('Do you really want to remove the product?')">Delete</button>
                                    </form>
                                </div>
                            </td>
                            
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/PHP/sparkinc/sparkinc/resources/views/admin/products.blade.php ENDPATH**/ ?>