<?php $__env->startSection('content'); ?>
    <div class="admin-content">
        <?php if(session('success')): ?>
            <div class="alert alert-danger" id="successMessage">
                <?php echo e(session('success')); ?>

            </div>
            <script>
            setTimeout(function() {
                document.getElementById('successMessage').style.display = 'none';
            }, 3000);
        </script>
        <?php endif; ?>

        <div class="container-fluid">
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="review">

                <div class="user">
                    <div class="username"><?php echo e($message->firstname); ?> <?php echo e($message->lastname); ?></div>
                    <div class="useremail"><em><?php echo e($message->email); ?></em></div>
                    <div class="emaildate"><?php echo e($message->created_at->format('F j, Y')); ?></div>
                    <div class="userreview"><?php echo e($message->message); ?></div>
                </div>
                <form action="<?php echo e(route('admin.messages.destroy', $message->id)); ?>" method="POST" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger admin-delete">Delete</button>
                </form>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/PHP/sparkinc/sparkinc/resources/views/admin/messages.blade.php ENDPATH**/ ?>