<?php $__env->startSection('content'); ?>

    <div class="banner blog-banner">
        <h1><?php echo e($title); ?></h1>
        <p>Spark Inc / <?php echo e($title); ?></p>
    </div>

    <?php if($blogs->isEmpty()): ?>
        <h4 style="text-align:center; margin-top:4%">No Blogs Posted</h4>
    <?php else: ?>
        <div class="blog-container blog-highlights">
            <div class="blog-thumbnails">
                <?php if(isset($latestBlog)): ?>
                    <div class="blog-card" data-aos="fade-up" data-aos-direction="1500">
                        <a href="<?php echo e(route('blog.read', ['id' => $latestBlog->id])); ?>">
                            <div class="blog-image">
                                <img src="<?php echo e(asset('storage/images/' . $latestBlog->image)); ?>" alt="product-image">
                            </div>
                        </a>
                        <div class="blog-text">
                            <h1><?php echo e($latestBlog->title); ?></h1>
                            <p style="color:gray" class="authordate">Posted by: <?php echo e($latestBlog->author); ?> on <?php echo e($latestBlog->created_at->format('d F, Y')); ?></p>
                            <p><?php echo \Illuminate\Support\Str::words($latestBlog->description, 10, '...'); ?></p>
                            <a href="<?php echo e(route('blog.read', ['id' => $latestBlog->id])); ?>">
                                <button class="btn btn-danger">
                                    Read Article
                                </button>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(isset($anotherlatestBlog)): ?>
                    <div class="blog-card" data-aos="fade-up" data-aos-direction="1500">
                        <a href="<?php echo e(route('blog.read', ['id' => $anotherlatestBlog->id])); ?>">
                            <div class="blog-image">
                                <img src="<?php echo e(asset('storage/images/' . $anotherlatestBlog->image)); ?>" alt="product-image">
                            </div>
                        </a>
                        <div class="blog-text">
                            <h1><?php echo e($anotherlatestBlog->title); ?></h1>
                            <p style="color:gray" class="authordate">Posted by: <?php echo e($anotherlatestBlog->author); ?> on <?php echo e($anotherlatestBlog->created_at->format('d F, Y')); ?></p>
                            <p><?php echo \Illuminate\Support\Str::words($anotherlatestBlog->description, 10, '...'); ?></p>
                            <button class="btn btn-secondary">
                                <a href="<?php echo e(route('blog.read', ['id' => $anotherlatestBlog->id])); ?>">Read Article</a>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="blog-lists" data-aos="fade-up" data-aos-direction="1500">
                <p>Top Blogs</p>
                <br>
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h1><?php echo e($blog->title); ?></h1>
                    <p style="color:gray" class="authordate">Posted by: <?php echo e($blog->author); ?> on <?php echo e($blog->created_at->format('d F, Y')); ?></p>
                    <p><?php echo \Illuminate\Support\Str::words($blog->description, 10, '...'); ?></p>
                    <p><a href="<?php echo e(route('blog.read', ['id' => $blog->id])); ?>">Read More &rarr;</a></p>
                    <hr class="resp-hr">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="all-blogs-container">
        <?php $__currentLoopData = $restoftheblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restoftheblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="small-blog-card">
                <a href="<?php echo e(route('blog.read', ['id' => $blog->id])); ?>">
                    <div class="small-blog-img">
                        <img src="<?php echo e(asset('storage/images/' . $restoftheblog->image)); ?>" alt="product-image">
                    </div>
                </a>
                <div class="small-blog-text">
                    <h1><?php echo e($restoftheblog->title); ?></h1>
                    <p style="color:gray" class="authordate">Posted by: <?php echo e($restoftheblog->author); ?> on <?php echo e($restoftheblog->created_at->format('d F, Y')); ?></p>
                    <p><?php echo \Illuminate\Support\Str::words($restoftheblog->description, 7, '...'); ?></p>
                    <p>
                        <a href="<?php echo e(route('blog.read', ['id' => $restoftheblog->id])); ?>">
                            <button class="btn btn-danger">
                                Read Article
                            </button>
                        </a>
                    </p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> 
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/PHP/sparkinc/sparkinc/resources/views/frontend/blog.blade.php ENDPATH**/ ?>